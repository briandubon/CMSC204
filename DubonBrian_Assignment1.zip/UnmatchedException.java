
public class UnmatchedException extends Exception {
	private static final long serialVersionUID = 1L;
	public UnmatchedException(String errorMessage) {
		super(errorMessage);
	}

}
