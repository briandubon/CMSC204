
public class WeakPasswordException extends Exception {
	public WeakPasswordException(String errorMessage) {
		super(errorMessage);
}
}
