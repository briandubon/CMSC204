import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordCheckerUtility {
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException{
		if(!comparePasswordsWithReturn(password, passwordConfirm))
			throw new UnmatchedException("The passwords do not match.");	
	}
	public static Boolean comparePasswordsWithReturn(String password, String passwordConfirm){
		return password.equals(passwordConfirm);
	}
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> Passwords) {
		ArrayList<String> invalidPasswords = new ArrayList<String>();
		for(int i = 0; i < Passwords.size(); i++) {
				try {
					if(!(isValidPassword(Passwords.get(i)))) {
						invalidPasswords.add(Passwords.get(i) + isValidPassword(Passwords.get(i)));
					}
				} catch (LengthException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password must be at least 6 characters long.");
				} catch (NoUpperAlphaException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password must contain at least one uppercase alphabetic character.");
				} catch (NoLowerAlphaException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password must contain at least one lowercase alphabetic character.");
				} catch (NoDigitException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password must contain at least one digit.");
				} catch (NoSpecialCharacterException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password must contain at least one special character.");
				} catch (InvalidSequenceException e) {
					invalidPasswords.add(Passwords.get(i) + " " + "The password cannot contain more than two of the same character in sequence.");
				}
		}
		return invalidPasswords;
	} 
	public static Boolean isValidLength(String password) throws LengthException{
		if(password.length() >= 6)
			return true;
		else {
			throw new LengthException("The password must be at least 6 characters long.");
		}
	}
	public static Boolean hasUpperAlpha(String password) throws NoUpperAlphaException{
		Boolean has = false;
		for(int i = 0; i < password.length(); i++) {
			if(Character.isUpperCase(password.charAt(i)))
				has = true;
		}
		if(!has)
			throw new NoUpperAlphaException("The password must contain at least one uppercase alphabetic character.");
		return has;
	}
	public static Boolean hasLowerAlpha(String password) throws NoLowerAlphaException {
		Boolean has = false;
		for(int i = 0; i < password.length(); i++) {
			if(Character.isLowerCase(password.charAt(i)))
				has = true;
		}
		if(!has) {
			throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character.");
		}
			
		return has;
	}
	public static Boolean hasSpecialChar(String password) throws NoSpecialCharacterException{
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(password);
		if(matcher.matches()) {
			throw new NoSpecialCharacterException("The password must contain at least one special character.");
		}
		return (!matcher.matches());
	}
	public static Boolean NoSameCharInSequence(String password) throws InvalidSequenceException{
		Boolean does = true;
		for(int i = 0; i < (password.length() - 3); i++) {
			if(password.charAt(i) == password.charAt(i+1) && password.charAt(i) == password.charAt(i+2) && password.charAt(i) == password.charAt(i+3))
				does = false;
		}
		if(does)
			throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence.");
		return does;
	}

	public static Boolean isValidPassword(String password) throws LengthException,
																  NoUpperAlphaException,
																  NoLowerAlphaException,
																  NoDigitException,
																  NoSpecialCharacterException,
																  InvalidSequenceException {
		Boolean valid = (isValidLength(password) && hasUpperAlpha(password) && hasLowerAlpha(password) 
		&& hasDigit(password)&& hasSpecialChar(password) && NoSameCharInSequence(password));
		return valid;
	}
	public static Boolean hasBetweenSixAndNineChars(String password) {
		if(password.length() >= 6 && password.length() <= 9)
			return true;
		else
			return false;
	}
	public static Boolean isWeakPassword(String password) throws WeakPasswordException, 
																 LengthException, 
																 NoUpperAlphaException, 
																 NoLowerAlphaException, 
																 NoDigitException, 
																 NoSpecialCharacterException, 
																 InvalidSequenceException {
		Boolean weak = (isValidPassword(password) && hasBetweenSixAndNineChars(password));
		if(weak)
			throw new WeakPasswordException("The password is OK but weak - it contains fewer than 10 characters.");
		return weak;
	}
	public static Boolean hasDigit(String password) throws NoDigitException{
		Boolean has = false;
		for(int i = 0; i < password.length(); i++) {
			if(Character.isDigit(password.charAt(i)))
				has = true;
		}
		if(!has)
			throw new NoDigitException("The password must contain at least one digit.");
		return has;
	}
}
