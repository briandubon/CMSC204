
public class NoLowerAlphaException extends Exception {
	private static final long serialVersionUID = 1L;
	public NoLowerAlphaException(String errorMessage) {
		super(errorMessage);
	}
}
