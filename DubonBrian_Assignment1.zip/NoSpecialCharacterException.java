
public class NoSpecialCharacterException extends Exception {
	public NoSpecialCharacterException(String errorMessage) {
		super(errorMessage);
	}
}
