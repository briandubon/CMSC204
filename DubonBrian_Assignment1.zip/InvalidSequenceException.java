
public class InvalidSequenceException extends Exception {
	public InvalidSequenceException(String errorMessage) {
		super(errorMessage);
	}
}
