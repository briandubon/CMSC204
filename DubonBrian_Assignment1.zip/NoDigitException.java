
public class NoDigitException extends Exception {
	public NoDigitException(String errorMessage) {
		super(errorMessage);
	}
}
