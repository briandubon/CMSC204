
public class NoUpperAlphaException extends Exception {

	public NoUpperAlphaException(String errorMessage) {
		super(errorMessage);
	}
}
