
public class LengthException extends Exception {
	
	public LengthException(String errorMessage) {
		super(errorMessage);
	}
}
