import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList <T> implements Iterable<T>{

	protected Node head;
	protected Node tail;
	protected int size;

	public BasicDoubleLinkedList() {
	    this.head = null;
	    this.tail = null;
	    this.size = 0;
	}
	
	public BasicDoubleLinkedList<T> addToEnd(T data) {
		// TODO Auto-generated method stub
	    Node newTail = new Node(data);

	    if (size == 0) {
	      head = newTail;
	      tail = head;
	    }
	    else{
	      tail.next = newTail;
	      newTail.prev = tail;
	      tail = newTail;
	    }
	    size++;
	    return this;
	}

	public int getSize() {
		return size;
	}

	public T getLast() {
		if (size == 0) {
			return null;
	    }
	    return tail.data;
    }


	public T getFirst() {
		if (size == 0) {
			return null;
		}
		return head.data;
	}


	public BasicDoubleLinkedList<T> addToFront(T data) {
		Node newHead = new Node(data);
		if (size == 0) {
			head = newHead;
			tail = head;
	    } 
		else {
	    	head.prev = newHead;
	    	newHead.next = head;
	    	head = newHead;
	    }
		size++;
		return this;
	}


	public ArrayList<T> toArrayList() {
		ArrayList<T> list = new ArrayList<>();
		Node node = head;

	    while (node != null) {
	    	list.add(node.data);
	    	node = node.next;
	    }
	    
	    return list;
	  }


	public T retrieveLastElement() {
		if (size == 0) {
			return null;
		}
		T item = tail.data;
		    
		if (size == 1) {
			head = null;
			tail = null;
		} 
		else {
			tail = tail.prev;
			tail.next = null;
		}
		size--;
		return item;
	}


	public T retrieveFirstElement() {
		if (size == 0) {
			return null;
		}
		T item = head.data;
		if (size == 1) {
			head = null;
			tail = null;
		} 
		else {
			head = head.next;
			head.prev = null;
		    }
		    size--;
		    return item;
		  }


	public BasicDoubleLinkedList<T> remove(T remove, Comparator<T> comparator) {
		Node node = head;
		while (node != null) {
			if (comparator.compare(remove, node.data) == 0) {
				if (node == head) {
					head = head.next;
				} 
				else if (node == tail) {
					tail = tail.prev;
		        } 
				else {
					node.prev.next = node.next;
		        }
		        size--;
		        return this;
			}
			node = node.next;
		}
		return this;
	}
	  
	public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException {
		return new NodeIterator();
	}


	public class Node {
		protected Node prev;
		protected Node next;
		protected T data;
	
		public Node(T data) {
			this.prev = null;
			this.next = null;
			this.data = data;
		}
	  }
	
	
	public class NodeIterator implements ListIterator<T> {
	
		protected Node current = head;
		protected Node tail;
	
		public boolean hasNext() {
			return current != null;
		}
	
		public boolean hasPrevious() {
			return tail != null;
		}
	
		public T next() throws NoSuchElementException {
			if (hasNext()) {
				tail = current;
		        current = current.next;
		        return tail.data;
			}
			throw new NoSuchElementException("No next elements available in List");
		}
	
		public T previous() throws NoSuchElementException {
			if (hasPrevious()) {
				current = tail;
		        tail = tail.prev;
		        return current.data;
			}
			throw new NoSuchElementException("No previous elements available in List");
		}
	
		public int nextIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	
		public int previousIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	
		public void remove() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	
		public void set(T data) throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	
		public void add(T data) throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	}
}
