//@author: Brian Dubon
import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> implements Iterable<T> {

	private Comparator<T> comparator;

	public SortedDoubleLinkedList(Comparator<T> comparator) {
		this.comparator = comparator;
	}

	public SortedDoubleLinkedList<T> add(T data) {
		Node node = head;
		Node newNode = new Node(data);

		if (size == 0) {
			head = newNode;
			tail = head;
			size++;
      
			return this;
      
		} 
		else if (comparator.compare(head.data, data) > 0) {
			newNode.next = head;
			head.prev = newNode;
			head = newNode;
			size++;
			return this;
		} 
		else {
			while (comparator.compare(node.data, data) < 0) {
				if (node.next == null) {
					node.next = newNode;
					newNode.prev = node;
					tail = newNode;
					size++;
					return this;
				} 
				else {
					node = node.next;
				}
			}

			node.prev.next = newNode;
			newNode.prev = node.prev;
			node.prev = newNode;
			newNode.next = node;
			size++;
			return this;
		}
	}
	
	public SortedDoubleLinkedList<T> remove(T data, Comparator<T> comparator) {
		return (SortedDoubleLinkedList<T>) super.remove(data, comparator);
	}

	public ListIterator<T> iterator() {
		return super.iterator();
	}

	public SortedDoubleLinkedList<T> addToEnd(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException("Invalid operation for sorted list");
	}
	
	public SortedDoubleLinkedList<T> addToFront(T data){
		throw new UnsupportedOperationException("Invalid operation for sorted list");
	}
}

