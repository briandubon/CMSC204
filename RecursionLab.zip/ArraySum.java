
public class ArraySum {
	public int sumOfArray(Integer[] array, int num) {
		int sum = 0;
		if(num == -1)
			return sum;
		
		sum += array[num];
		
		return sum + sumOfArray(array, num - 1);
	}
}
