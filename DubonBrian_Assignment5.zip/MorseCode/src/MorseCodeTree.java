import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String>{
	
	TreeNode<String> root = new TreeNode<String>("");
	
	public MorseCodeTree() {
		buildTree();
	}
	/*
	 * Gets the root
	 * @return root
	 */
	public TreeNode<String> getRoot(){
		return root;
	}
	/*
	 * Sets the root
	 * @param newNode
	 */
	public void setRoot(TreeNode<String> newNode) {
		root = newNode;
	}
	/*
	 * Adds element to the correct position in the tree based on the code This method will call the recursive method addNode
	 * @param code and letter
	 */
	public void insert(String code, String letter) {
		addNode(root, code, letter);
	}
	/*
	 * This is a recursive method that adds element to the correct position in the tree based on the code.
	 * @param root, code, and letter
	 */
	public void addNode(TreeNode<String> root, String code, String letter) {
		if(code.length() == 1) {
			if(code.charAt(0) == '-') {
				root.rightChild = new TreeNode<String>(letter);
			}
			else if(code.charAt(0) == '.')
			{
				root.leftChild = new TreeNode<String>(letter);
			}
		}
		else
		{
			if(code.charAt(0) == '-') {
				addNode(root.rightChild, code.substring(1), letter);
			}
			else if(code.charAt(0) == '.')
			{
				addNode(root.leftChild, code.substring(1), letter);
			}
		}
	}
	/*
	 * Fetch the data in the tree based on the code
	 * @param code
	 * @return got
	 */
	public String fetch(String code) {
		String got = fetchNode(root, code);
		return got;
	}
	/*
	 * This is the recursive method that fetches the data of the TreeNode that corresponds with the code
	 * @param root and code
	 * @return node
	 */
	public String fetchNode(TreeNode<String> root, String code) {
		if(code.length() == 1) {
			if(code.charAt(0) == '-') {
				return root.rightChild.getData();
			}
			else if(code.charAt(0) == '.') {
				return root.leftChild.getData();
			}
		}
		else
		{
			if(code.charAt(0) == ' ') {
				return "/";
			}
			if(code.charAt(0) == '.') {
				return fetchNode(root.leftChild, code.substring(1));
			}
			else if (code.charAt(0) == '-'){
				return fetchNode(root.rightChild, code.substring(1));
			}
		}
		return null;
		
	}
	/*
	 * Not supported
	 */
	public MorseCodeTree delete(String data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}
	/*
	 * Not supported
	 */
	public MorseCodeTree update() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}
	/*
	 * This method builds the MorseCodeTree by inserting the nodes of the tree level by level based on the code
	 */
	public void buildTree() {
		setRoot(new TreeNode<String>(""));
		
        insert(".", "e"); insert("-", "t");
        insert("..", "i"); insert(".-", "a"); insert("-.", "n"); insert("--", "m");
        insert("...", "s"); insert("..-", "u");insert(".-.", "r"); insert(".--", "w");
        insert("-..", "d"); insert("-.-", "k");insert("--.", "g"); insert("---", "o"); 
        insert("....", "h"); insert("...-", "v"); insert("..-.", "f"); insert(".-..", "l");
        insert(".--.", "p"); insert(".---", "j"); insert("-...", "b"); insert("-..-", "x");
        insert("-.-.", "c"); insert("-.--", "y"); insert("--..", "z"); insert("--.-", "q");
	}
	/*
	 * Returns an ArrayList of the items in the linked Tree in LNR (Inorder) Traversal order
	 */
	public ArrayList<String> toArrayList() {
		ArrayList<String> line = new ArrayList<String>();
		LNRoutputTraversal(root, line);
		return line;
	}
	/*
	 * The recursive method to put the contents of the tree in an ArrayList in LNR (Inorder)
	 */
	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		// TODO Auto-generated method stub
		if(root != null) {
			LNRoutputTraversal(root.leftChild, list);
			list.add(root.getData());
			LNRoutputTraversal(root.rightChild, list);
		}
	}
	
}
