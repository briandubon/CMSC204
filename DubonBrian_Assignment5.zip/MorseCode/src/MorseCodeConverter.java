import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {
	static MorseCodeTree codeTree = new MorseCodeTree();
	
	public MorseCodeConverter() {
		
	}
	/*
	 * Converts a file of Morse code into English
	 * @param selectedFile
	 * @return converted
	 */
	public static String convertToEnglish(File selectedFile) {
		// TODO Auto-generated method stub
		String converted = "";
		try {
			Scanner input = new Scanner(selectedFile);
			converted = input.nextLine() + " ";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return convertToEnglish(converted);
	}
	/*
	 * Converts Morse code into English.
	 * @param text
	 * @return phrase
	 */
	public static String convertToEnglish(String text) {
		// TODO Auto-generated method stub
		StringBuilder phrase = new StringBuilder();
		String letter = "";
		for(int i = 0; i < text.length(); i++) {
			while(!(text.charAt(i) == ' '))
			{
				letter += String.valueOf(text.charAt(i));
				if(text.charAt(i) == '/') {
					i++;
					letter = letter.substring(0, letter.length()-1);
					phrase.append(" ");
				}
				i++;
			}
			String code = codeTree.fetch(letter);
			phrase.append(code);
			letter = "";
		}
		return phrase.toString();
	}
	/*
	 * Returns a string with all the data in the tree in LNR order
	 * @return tree
	 */
	public static String printTree() {
		StringBuilder tree = new StringBuilder();
		MorseCodeTree codeTree = new MorseCodeTree();
		for(String item : codeTree.toArrayList())
			tree.append(item).append(" ");
		
		return tree.toString();
	}

}