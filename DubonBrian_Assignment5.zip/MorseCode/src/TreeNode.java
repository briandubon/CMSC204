public class TreeNode<T> {
	T dataSet;
	TreeNode<T> leftChild;
	TreeNode<T> rightChild;
	/*
	 * Create a new TreeNode with left and right child and data set set to null
	 */
	public TreeNode() {
		dataSet = null;
		leftChild = null;
		rightChild = null;
	}
	/*
	 * Create a new TreeNode with left and right child set to null and data set to the dataNode
	 * @param dataNode
	 */
	public TreeNode(T dataNode) {
		dataSet = dataNode;
		leftChild = null;
		rightChild = null;
	}
	/*
	 * Used for making deep copies
	 * @param node
	 */
	public TreeNode(TreeNode<T> node) {
		this.dataSet = node.dataSet;
		this.leftChild = node.leftChild;
		this.rightChild = node.rightChild;
	}
	/*
	 * Return the data within this TreeNode
	 * @return dataSet
	 */
	public T getData() {
		return dataSet;
	}
	/*
	 * Set the data within the TreeNode
	 * @param data
	 */
	public void setData(T data) {
		dataSet = data;
	}
}