
public class CourseDBElement implements Comparable {
	String courseID;
	int CRN;
	int numCredits;
	String roomNum;
	String instructor;
	/**
	 * Default constructor that sets default values
	 */
	public CourseDBElement() {
		courseID = null;
		CRN = 0;
		numCredits = 0;
		roomNum = null;
		instructor = null;
	}
	/**
	 * Constructor that sets values to what was passed through
	 */
	public CourseDBElement(String courseID, int CRN, int numCredits, String roomNum, String instructor) {
		this.courseID = courseID;
		this.CRN = CRN;
		this.numCredits = numCredits;
		this.roomNum = roomNum;
		this.instructor = instructor;
	}
	/**
	 * Compares this class with another class
	 */
	public int compareTo(CourseDBElement element) {
		if(element.CRN == CRN) {
			return 0;
		}
		else if(element.CRN < CRN) {
			return -1;
		}
		else {
			return 1;
		}
	}
	/**
	 * Set the course ID
	 * @param courseID
	 */
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	/**
	 * Get the course ID
	 * @return the course ID
	 */
	public String getCourseID() {
		return courseID;
	}
	/**
	 * Sets the CRN Number
	 * @param CRN
	 */
	public void setCRN(int CRN) {
		this.CRN = CRN;
	}
	/**
	 * Gets the CRN
	 * @return the CRN
	 */
	public int getCRN() {
		return CRN;
	}
	/**
	 * Sets the number of credits
	 * @param numCredits
	 */
	public void setNumberOfCredits(int numCredits) {
		this.numCredits = numCredits;
	}
	/**
	 * Gets the number of credits
	 * @return number of credits
	 */
	public int getNumberOfCredits() {
		return numCredits;
	}
	/**
	 * Sets room number
	 * @param roomNum
	 */
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}
	/**
	 * Gets the room number
	 * @return the room number
	 */
	public String getRoomNum() {
		return roomNum;
	}
	/**
	 * Gets the instructor
	 * @return instructor
	 */
	public String getInstructor() {
		return instructor;
	}
	/**
	 * Sets the instructor
	 * @param instructor
	 */
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	/**
	 * Gets the hash code, which is the crn number, converted
	 * into a String, then calling on the hashCode of that string
	 */
	public int hashCode() {
		String crn = Integer.toString(CRN);
		return crn.hashCode();
	}
	/**
	 * Gets the attributes of CourseDBElement
	 */
	public String toString() {
		String course = "Course:"+ courseID +" CRN:"+ CRN +" Credits:"+ numCredits +" Instructor:"+ instructor +" Room:"+ roomNum;
		return course;
	}
}
