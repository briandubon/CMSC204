import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
	CourseDBStructure cdbs = new CourseDBStructure(20);
	/**
	 * Adds an element to the structure
	 */
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		// TODO Auto-generated method stub
		CourseDBElement cde = new CourseDBElement(id,crn,credits,roomNum,instructor);
		cdbs.add(cde);
	}
	/**
	 * Gets an element from the structure
	 */
	@Override
	public CourseDBElement get(int crn) {
		// TODO Auto-generated method stub
		try {
			return cdbs.get(crn);
		}
		catch(IOException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	/**
	 * Reads a file and adds everything in that file into the structure
	 */
	@Override
	public void readFile(File input) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(input);
		int cred, crn;
		CourseDBElement cde;
		String courses;
		String[] course;
		while (scan.hasNextLine()) {
			courses = scan.nextLine();
			course = courses.split(" ",5);
			crn = Integer.parseInt(course[1]);
			cred = Integer.parseInt(course[2]);
			cde = new CourseDBElement(course[0],crn,cred,course[3],course[4]);
			cdbs.add(cde);
		}
	}
	/**
	 * Gets an element's data
	 */
	@Override
	public ArrayList<String> showAll() {
		// TODO Auto-generated method stub
		return cdbs.showAll();
	}

}
