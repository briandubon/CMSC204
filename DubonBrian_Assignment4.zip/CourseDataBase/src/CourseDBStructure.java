import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {
	int hashSize = 0;
	int elementSize = 0;
	LinkedList[] hashTable;
	/**
	 * Constructor that sets up the hash table
	 */
	public CourseDBStructure(int size) {
		hashSize = size;
		hashTable = new LinkedList[hashSize];
	}
	/**
	 * Constructor that is only used for testing
	 */
	public CourseDBStructure(String testing, int size) {
		hashSize = size;
		hashTable=new LinkedList[hashSize];
	}
	/**
	 * Adds an element to the structure
	 */
	@Override
	public void add(CourseDBElement element) {
		// TODO Auto-generated method stub
		int code;
		code=Math.abs(element.hashCode()) % hashSize;
		LinkedList<CourseDBElement> current = hashTable[code];
		if(current == null) {
			hashTable[code] = new LinkedList<CourseDBElement>();
			
		}
		hashTable[code].add(element);
		elementSize++;
	}
	/**
	 * Gets an element with the crn number passed through
	 */
	@Override
	public CourseDBElement get(int crn) throws IOException {
		// TODO Auto-generated method stub
		String crn1 = Integer.toString(crn);
		int code = Math.abs(crn1.hashCode())% hashSize;
		if(hashTable[code] == null) {
			throw new IOException();
		}
		else{
			return (CourseDBElement)hashTable[code].get(0);
		}
	}

	/**
	 * returns all courses
	 */
	public ArrayList<String> showAll() {
		// TODO Auto-generated method stub
		ArrayList<String> courses = new ArrayList<String>();
		for(int i = 0;i < hashSize;i++) {
			while(hashTable[i] != null) {
				for(int j = 0;j < hashTable[i].size();j++) {
					CourseDBElement element = (CourseDBElement)hashTable[i].get(j);
					courses.add("\n" + element.toString());
				}
				break;
			}
		}
		return courses;
	}
	/**
	 * Size of hashTable
	 */
	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return hashSize;
	}


}
