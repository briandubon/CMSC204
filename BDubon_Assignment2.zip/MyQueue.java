import java.util.ArrayList;

public class MyQueue<T> implements QueueInterface<T>{

	int sizeOfQueue;
	ArrayList<T> list;
	public MyQueue(int num) {
		sizeOfQueue = num;
		list = (ArrayList<T>) new ArrayList<Object>();
	}
	public MyQueue() {
		sizeOfQueue = 100;
		list = (ArrayList<T>) new ArrayList<Object>();
	}
	/**
	 * Determines if Queue is empty
	 * @return true if Queue is empty, false if not
	 */
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (list.size() == 0);
	}
	/**
	 * Determines of the Queue is Full
	 * @return true if Queue is full, false if not
	 */
	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return (list.size() == sizeOfQueue);
	}
	/**
	 * Deletes and returns the element at the front of the Queue
	 * @return the element at the front of the Queue
	 * @throws QueueUnderflowException if queue is empty
	 */
	@Override
	public T dequeue() throws QueueUnderflowException {
		// TODO Auto-generated method stub
		if(isEmpty())
			throw new QueueUnderflowException();
		T item;
		item = list.get(0);
		list.remove(0);
		return item;
	}
	/**
	 * Returns number of elements in the Queue
	 * @return the number of elements in the Queue
	 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return list.size();
	}
	/**
	 * Adds an element to the end of the Queue
	 * @param e the element to add to the end of the Queue
	 * @return true if the add was successful
	 * @throws QueueOverflowException if queue is full
	 */
	@Override
	public boolean enqueue(T e) throws QueueOverflowException {
		// TODO Auto-generated method stub
		if(isFull())
			throw new QueueOverflowException();
		list.add(e);
		return true;
	}
	/**
	 * Returns the string representation of the elements in the Queue, 
	 * the beginning of the string is the front of the queue
	 * @return string representation of the Queue with elements
	 */
	@Override
	public String toString(String delimiter) {
		// TODO Auto-generated method stub
		String line = "";
		for(int i = 0; i < list.size(); i++) {
		line += list.get(i);
		if(i < (list.size() - 1))
			line += delimiter;
		}
		return line;
	}
	 /**
	  * Fills the Queue with the elements of the ArrayList, First element in the ArrayList
	  * is the first element in the Queue
	  * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE QUEUE, if you use the
	  * list reference within your Queue, you will be allowing direct access to the data of
	  * your Queue causing a possible security breech.
	  * @param list elements to be added to the Queue
	  * @throws QueueOverflowException if queue is full
	 
	  */
	@Override
	public void fill(ArrayList<T> list) {
		// TODO Auto-generated method stub
		for(int i = 0; i < list.size(); i++) {
			this.list.add(list.get(i));
		}
	}
	/**
	 * Returns the string representation of the elements in the Queue, the beginning of the string is the front of the queue
	 * Place the delimiter between all elements of the Queue
	 * @return string representation of the Queue with elements separated with the delimiter
	 */
	public String toString() {
		String line = "";
		for(int i = 0; i < list.size(); i++)
			line += list.get(i);
		return line;
	}

}


