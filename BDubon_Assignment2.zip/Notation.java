
public class Notation {

	public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException {
		MyQueue<Character> postFix = new MyQueue<Character>();
		MyStack<Character> operators = new MyStack<Character>();
		
		for (int i = 0; i < infix.length(); i++) {
			char c = infix.charAt(i);
			if (c == ' ') {
				continue;
			}
			if (Character.isDigit(c)) {
				try {
					postFix.enqueue(c);
				} catch (QueueOverflowException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if (c == '(') {
				try {
					operators.push(c);
				} catch (StackOverflowException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				else if (c == ')') {
					while (operators.peek() != '(') {
						try {
							postFix.enqueue(operators.pop());
						} catch (QueueOverflowException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (StackUnderflowException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if (operators.isEmpty()) {
							throw new InvalidNotationFormatException();
						}
					}
					try {
						operators.pop();
					} catch (StackUnderflowException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if (!(c >= 'a' && c <= 'z') && !(c >= '0' && c <= '9') && !(c >= 'A' && c <= 'Z')) {
					while (!operators.isEmpty() && prec(c) <= prec(operators.peek())) {
					try {
						postFix.enqueue(operators.pop());
					} catch (QueueOverflowException | StackUnderflowException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
					try {
						operators.push(c);
					} catch (StackOverflowException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			while (!operators.isEmpty()) {
			try {
				postFix.enqueue(operators.pop());
			} catch (QueueOverflowException | StackUnderflowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			String solution = "";
			while (!postFix.isEmpty()) {
			try {
				solution = solution + postFix.dequeue();
			} catch (QueueUnderflowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			// return solution
			return solution;
		}
		 
	public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException{
		// TODO Auto-generated method stub
		MyStack<String> infix = new MyStack<String>();

		for (int i = 0; i < postfix.length(); i++) {
			char c = postfix.charAt(i);
			if (c == ' ') {
				continue;
			}
			if (Character.isDigit(c)) {
				try {
					infix.push(Character.toString(c));
				} catch (StackOverflowException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				if (infix.size() < 2) {
					throw new InvalidNotationFormatException();
				}
				String c1 = "";
				try {
					c1 = infix.pop();
				} catch (StackUnderflowException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				String c2 = "";
				try {
					try {
						c2 = infix.pop();
					} catch (StackUnderflowException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String exp = '(' + c2 + c + c1 + ')';
					infix.push(exp);
				} catch (StackOverflowException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		if (infix.size() != 1) {
			throw new InvalidNotationFormatException();
		}
		String t = "";
		try {
			t = infix.pop();
		} catch (StackUnderflowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
		}
		 
		// Driver code

	public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException{
		MyStack<Double> evalutated = new MyStack<Double>();
		for (int i = 0; i < postfixExpr.length(); i++) {
			char c = postfixExpr.charAt(i);
			if (c == ' ') {
				continue;
			}
			if (Character.isDigit(c)) {
				try {
					evalutated.push(Double.parseDouble(Character.toString(c)));
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (StackOverflowException e) {
					e.printStackTrace();
				}
			}
			else {
				if (evalutated.size() < 2) {
				throw new InvalidNotationFormatException();
				}
				try {
					double op2 = evalutated.pop();
					double op1 = evalutated.pop();
					switch (c) {
					case '+':
						evalutated.push(op1 + op2);
					break;
			
					case '-':
						evalutated.push(op1 - op2);
					break;
			
					case '/':
						evalutated.push(op1 / op2);
					break;
			
					case '*':
						evalutated.push(op1 * op2);
					break;
					}
				} catch (StackOverflowException | StackUnderflowException e) {
					e.printStackTrace();
				}
			}
		}
		if (evalutated.size() != 1) {
			throw new InvalidNotationFormatException();
		}
		Double t = 0.0;
		try {
			t = evalutated.pop();
		} catch (StackUnderflowException e) {
			e.printStackTrace();
		}
		return t;
	}
	
   static int prec(char x)
    {
	   if (x == '+' || x == '-')  
		   return 1;  
	   if (x == '*' || x == '/')  
		   return 2;  
	   else
		   return 0;  
	   }  
}
