import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class CarQueue {

	Thread t = new Thread();
	Queue<Integer> queue = new LinkedList<>();
	Random r = new Random();
	
	public CarQueue() {
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		queue.add(r.nextInt(4));
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void addToQueue() {
		class AddRan implements Runnable {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				queue.add(r.nextInt(4));
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		new Thread(new AddRan()).start();
	}
	public int deleteQueue() {
		if(queue.isEmpty())
			return -1;
		return queue.remove();
	}
	
}
