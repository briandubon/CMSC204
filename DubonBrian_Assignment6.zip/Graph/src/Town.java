public class Town implements Comparable<Town>{
	String name;
	public Town(String name) {
		this.name = name;
	}
	public Town(Town town) {
		this.name = town.getName();
	}
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	public String toString() {
		return name + "";
	}
	public int compareTo(Town town) {
		if(town.getName() == name) {
			return 0;
		}
		else {
			return -1;
		}
	}
	public boolean equals(Object o) {
		if(o.hashCode() == name.hashCode()) {
			return true;
		}
		else {
			return false;
		}
	}
	public int hashCode() {
		return name.hashCode();
	}
}
