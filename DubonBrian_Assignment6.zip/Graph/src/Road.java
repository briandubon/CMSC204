public class Road implements Comparable<Road> { 
	Town start;
	Town end;
	int degrees;
	String name;
	
	public Road(Town start, Town end, int degrees, String name) {
		this.start = start;
		this.end = end;
		this.degrees = degrees;
		this.name = name;
	}
	public Road(Town start, Town end, String name) {
		this.start = start;
		this.end = end;
		degrees = 1;
		this.name = name;
	}
	public int getWeight() {
		return degrees;
	}
	public Town getDestination() {
		return end;
	}
	public Town getSource() {
		return start;
	}
	public String getName() {
		return name;
	}
	public String toString() {
		
		return name + "";
	}
	public boolean equals(Road road) {
		if(road.start.equals(start) && road.end.equals(end)) {
			return true;
		}
		else if(road.start.equals(end) && road.end.equals(start)) {
			return true;
		}
		else 
			return false;
	}
	
	@Override
	public int compareTo(Road road) {
		// TODO Auto-generated method stub
		if(road.start == start && road.end == end) {
			return 0;
		}
		else if(road.start == end || road.end == start) {
			return 0;
		}
		else 
			return -1;
	}
}
