import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Queue;

public class Graph implements GraphInterface<Town, Road>{

	HashMap<String, HashMap<String, Road>> matrix = new HashMap<String, HashMap<String, Road>>();
	public Set<Road> edges;
	public Town vertices;
	public ArrayList<Road> roads;
	private int[] distance;
	private String[] prev;
	private ArrayList<String> towns;
	public Graph() {
		towns = new ArrayList<>();
		roads = new ArrayList<>();
	}
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		// TODO Auto-generated method stub
		Road newRoad = new Road(sourceVertex, destinationVertex, "Compare");
		for(int i = 0; i < roads.size(); i++) {
			if(newRoad.equals(roads.get(i)))
				return roads.get(i);
		}
		return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		// TODO Auto-generated method stub
		Road road = new Road(sourceVertex, destinationVertex, description);
		roads.add(road);
		return road;
	}

	@Override
	public boolean addVertex(Town v) {
		// TODO Auto-generated method stub
		if(v == null)
			throw new NullPointerException();
		if(containsVertex(v))
			return false;
		towns.add((v.toString()));
		return true;
	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		Road newRoad = new Road(sourceVertex, destinationVertex, "Compare");
		for(int i = 0; i < roads.size(); i++) {
			if(newRoad.equals(roads.get(i)))
				return true;
		}
		return false;
	}
	public int getEdgeIndex(Road r) {
		for(int i = 0; i < roads.size(); i++) {
			if(r.equals(roads.get(i)))
				return i;
		}
		return 0;
	}

	@Override
	public boolean containsVertex(Town v) {
		// TODO Auto-generated method stub
		for(int i = 0; i < towns.size(); i++) {
			if(towns.get(i).equals(v.toString())) {
				return true;
			}
		}
		return false;
	}
	public int getVertexIndex(Town v) {
		int j = 0;
		for(int i = 0; i < towns.size(); i++) {
			if(towns.get(i).equals(v.toString())) {
				j = i;
				return j;
			}
		}
		return j;
	}

	@Override
	public Set<Road> edgeSet() {
		Set<Road> road = new HashSet<Road>();
		for(Road road1 : roads)
			road.add(road1);
		return road;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) {
		// TODO Auto-generated method stub
		Town t = vertex;
		Set<Road> road = new HashSet<>();
		if (t == null) {
			throw new NullPointerException();
		}
		if (t.getName() == null) {
			throw new IllegalArgumentException();
		}
		for(Road road1 : roads) {
			if(t.equals(road1.getSource()) || t.equals(road1.getDestination())) {
				road.add(road1);
			}
		}
		return road;
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		// TODO Auto-generated method stub
		Road temp = new Road(sourceVertex, destinationVertex, description);
		Road hold;
		for(Road road1 : roads) {
			if(description.equals(road1.getName())) {
				hold = road1;
				roads.remove(road1);
				return hold;
			}
		}
		return null;
	}

	@Override
	public boolean removeVertex(Town v) {
		// TODO Auto-generated method stub
		if(!containsVertex(v))
			return false;
		towns.remove(getVertexIndex(v));
		return true;
	}

	@Override
	public Set<Town> vertexSet() {
		// TODO Auto-generated method stub
		Set<Town> vertexSet = new HashSet<Town>();
		for(String vertex : towns)
			vertexSet.add(new Town(vertex));
		return vertexSet;
	}

	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		// TODO Auto-generated method stub
		dijkstraShortestPath(sourceVertex);
		ArrayList<String> path = new ArrayList<>();
		ArrayList<Integer> pathWeight = new ArrayList<>();
		ArrayList<String> finalPath = new ArrayList<>();

		int index = towns.indexOf(destinationVertex.getName());
		path.add(destinationVertex.getName());
		while (prev[index] != null) {
			path.add(prev[index]);
			pathWeight.add(distance[index]);
			index = towns.indexOf(prev[index]);
		}
		Collections.reverse(path);
		Collections.reverse(pathWeight);
		int count = 0;
		for (int i = 0; i < path.size() - 1; i++) {
			String sourceName = path.get(i);
			String destinationName = path.get(i + 1);
			Road road = (Road) this.getEdge(new Town(sourceName), new Town(destinationName));
			String roadName = road.getName();
			int distance = pathWeight.get(i) - count;
			String pathString = sourceName + " via " + roadName + " to " + destinationName + " " + distance + " mi";
			finalPath.add(pathString);
			count += distance;
		}
		return finalPath;
	}

	@Override
	public void dijkstraShortestPath(Town sourceVertex) {
        int n = roads.size();
        Map<Integer, Integer> distances = new HashMap<>();
        boolean[] visited = new boolean[n];
        PriorityQueue<Town> pq = new PriorityQueue<>();
        pq.offer(sourceVertex);
        while (!pq.isEmpty()) {
            Town node = pq.poll();
            int u = getVertexIndex(node);
            int dist = 0;
            if (visited[u]) {
                continue;
            }
            visited[u] = true;
            distances.put(u, dist);
            for (Road e : roads) {
                Town v = e.getDestination();
                if (!visited[getVertexIndex(v)]) {
                    pq.offer(new Town(v));
                }
            }
        }
	}
}
