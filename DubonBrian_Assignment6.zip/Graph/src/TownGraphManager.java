import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Set;

import org.w3c.dom.Node;

public class TownGraphManager implements TownGraphManagerInterface {

	Graph graph = new Graph();
	ArrayList<Road> roads;
	ArrayList<Town> towns;
	
	public TownGraphManager() {
	roads = new ArrayList<>();
	towns = new ArrayList<>();
	}
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		// TODO Auto-generated method stub
		Town towns1 = new Town(town1);
		Town towns2 = new Town(town2);
		Road road = new Road(towns1, towns2, weight, roadName);
		roads.add(road);
		return true;
	}

	@Override
	public String getRoad(String town1, String town2) {
		// TODO Auto-generated method stub
		Town t1 = new Town(town1);
		Town t2 = new Town(town2);
		Road newRoad = new Road(t1, t2, "Compare");
		for(int i = 0; i < roads.size(); i++) {
			if(newRoad.equals(roads.get(i)))
				return roads.get(i).getName();
		}
		return null;
	}

	@Override
	public boolean addTown(String v) {
		// TODO Auto-generated method stub
		if(containsTown(v))
			return false;
		Town add = new Town(v);
		towns.add(add);
		return true;
	}

	@Override
	public Town getTown(String name) {
		// TODO Auto-generated method stub
		Town get = new Town(name);
		for(int i = 0; i < towns.size(); i++) {
			if(get.equals(towns.get(i)))
				return towns.get(i);
		}
		return null;
	}

	@Override
	public boolean containsTown(String v) {
		// TODO Auto-generated method stub
		Town v1 = new Town(v);
		for(int i = 0; i < towns.size(); i++) {
			if(v1.equals(towns.get(i)))
				return true;
		}
		return false;
	}

	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		// TODO Auto-generated method stub
		Town temp1 = new Town(town1);
		Town temp2 = new Town(town2);
		Road road = new Road(temp1, temp2, "Temp");
		for(Road road1 : roads) {
			if(road.equals(road1))
				return true;
		}
		return false;
	}

	@Override
	public ArrayList<String> allRoads() {
		// TODO Auto-generated method stub
		ArrayList<String> all = new ArrayList<>();
		for(Road road : roads)
			all.add((road.toString()));
		return all;
	}

	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		// TODO Auto-generated method stub
		Town temp1 = new Town(town1);
		Town temp2 = new Town(town2);
		Road temp = new Road(temp1, temp2, road);
		for(Road road1 : roads) {
			if(road.equals(road1.getName())) {
				roads.remove(road1);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteTown(String v) {
		// TODO Auto-generated method stub
		if(!containsTown(v))
			return false;
		Town temp = new Town(v);
		towns.remove(temp);
		return true;
	}

	@Override
	public ArrayList<String> allTowns() {
		// TODO Auto-generated method stub
		ArrayList<String> all = new ArrayList<>();
		for(Town town : towns)
			all.add(town.toString());
		Collections.sort(all);
		return all;
	}

	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		// TODO Auto-generated method stub
		return graph.shortestPath(new Town(town1), new Town(town2));
	}
	
    public void populateTownGraph(File file) throws FileNotFoundException{
        Scanner scan = new Scanner(file);
        while(scan.hasNextLine()){
            String line = scan.nextLine();
            String[] splitText = line.split(",");
            String roadName = splitText[0];
            splitText = splitText[1].split(";");
            int weight = Integer.parseInt(splitText[0]);
            String town1 = splitText[1];
            String town2 = splitText[2];
            graph.addVertex(new Town(town1));
            graph.addVertex(new Town(town2));
            graph.addEdge(new Town(town1), new Town(town2), weight, roadName);
        }
        scan.close();
    }

}
